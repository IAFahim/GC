package com.github.iafahim.gccopy

import com.intellij.notification.NotificationGroupManager
import com.intellij.notification.NotificationType
import com.intellij.openapi.actionSystem.ActionUpdateThread
import com.intellij.openapi.actionSystem.AnAction
import com.intellij.openapi.actionSystem.AnActionEvent
import com.intellij.openapi.actionSystem.CommonDataKeys
import com.intellij.openapi.application.ApplicationManager
import com.intellij.openapi.project.Project
import com.intellij.openapi.ui.Messages
import com.intellij.openapi.vfs.VirtualFile
import java.io.File
import java.util.concurrent.TimeUnit

abstract class AbstractGcCopyAction : AnAction() {

    private val notificationGroupId = "gc.notifications"
    private val pathPrefix = System.getProperty("user.home").let { home ->
        "$home/.local/bin:$home/bin:/usr/local/bin"
    }

    override fun getActionUpdateThread(): ActionUpdateThread = ActionUpdateThread.BGT

    override fun update(event: AnActionEvent) {
        event.presentation.isEnabledAndVisible = targetDirectory(event) != null
    }

    override fun actionPerformed(event: AnActionEvent) {
        val project = event.project
        val directory = targetDirectory(event) ?: return

        val invocation = getGcInvocation(project) ?: return

        ApplicationManager.getApplication().executeOnPooledThread {
            val outcome = runGc(directory, invocation)
            ApplicationManager.getApplication().invokeLater {
                announce(project, outcome)
            }
        }
    }

    abstract fun getGcInvocation(project: Project?): String?

    private fun targetDirectory(event: AnActionEvent): File? {
        val selected: VirtualFile = event.getData(CommonDataKeys.VIRTUAL_FILE) ?: return null
        val folder = if (selected.isDirectory) selected else selected.parent ?: return null
        return File(folder.path)
    }

    private fun runGc(directory: File, invocation: String): Outcome {
        val command = "export PATH=\"$pathPrefix:\$PATH\"; $invocation"
        val process = ProcessBuilder("bash", "-lc", command)
            .directory(directory)
            .redirectErrorStream(true)
            .start()
        val transcript = process.inputStream.bufferedReader().readText().trim()
        val finished = process.waitFor(60, TimeUnit.SECONDS)
        return when {
            !finished -> {
                process.destroyForcibly()
                Outcome.Failure(directory, "gc timed out")
            }
            process.exitValue() == 0 -> Outcome.Success(directory)
            else -> Outcome.Failure(directory, transcript.ifBlank { "gc exited ${process.exitValue()}" })
        }
    }

    private fun announce(project: Project?, outcome: Outcome) {
        val group = NotificationGroupManager.getInstance().getNotificationGroup(notificationGroupId)
        val notification = when (outcome) {
            is Outcome.Success -> group.createNotification(
                "Copied ${outcome.directory.name} to clipboard",
                NotificationType.INFORMATION,
            )
            is Outcome.Failure -> group.createNotification(
                "gc failed in ${outcome.directory.name}",
                outcome.detail,
                NotificationType.ERROR,
            )
        }
        notification.notify(project)
    }

    private sealed interface Outcome {
        data class Success(val directory: File) : Outcome
        data class Failure(val directory: File, val detail: String) : Outcome
    }
}

class GcCopyAction : AbstractGcCopyAction() {
    override fun getGcInvocation(project: Project?): String {
        return "gc -e cs -z // \\n\\n --force"
    }
}

class GcCopyCustomAction : AbstractGcCopyAction() {
    override fun getGcInvocation(project: Project?): String? {
        return Messages.showInputDialog(
            project,
            "Enter custom gc parameters:",
            "Copy with gc (Custom)",
            Messages.getQuestionIcon(),
            "gc -e cs -z // \\n\\n --force",
            null
        )
    }
}
